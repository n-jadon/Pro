package com.capgemini.Product_Cart_Management.repository;

import java.util.List;

import com.capgemini.Product_Cart_Management.dto.ProductDTO;

public interface IProductRepo {
	public ProductDTO create(ProductDTO Product);

	public ProductDTO update(String id, ProductDTO Product);

	public ProductDTO delete(String id);

	public List<ProductDTO> view();

	public ProductDTO findById(String id);

}
