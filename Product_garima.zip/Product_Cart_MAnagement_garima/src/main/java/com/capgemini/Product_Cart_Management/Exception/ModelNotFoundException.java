package com.capgemini.Product_Cart_Management.Exception;

public class ModelNotFoundException extends Exception {
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
}
