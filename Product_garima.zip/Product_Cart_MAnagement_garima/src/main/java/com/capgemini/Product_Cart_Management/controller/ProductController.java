package com.capgemini.Product_Cart_Management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Product_Cart_Management.Exception.ModelNotFoundException;
import com.capgemini.Product_Cart_Management.dto.ProductDTO;
import com.capgemini.Product_Cart_Management.service.IProductService;

@RestController
@RequestMapping  /*("/product") */
public class ProductController {

	@Autowired
	private IProductService service;

	@RequestMapping(value = "products", method = RequestMethod.GET)
	public List<ProductDTO> list() {

		return service.view();

	}

	@RequestMapping(method = RequestMethod.POST, value = "products")
	public ProductDTO save(@RequestBody ProductDTO Product) {
		return service.create(Product);
	}

	@RequestMapping(method = RequestMethod.GET, value = "products/{id}")
	public ProductDTO get(@PathVariable(name = "id") String id) {
		return service.findById(id);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "products/{id}")
	public ProductDTO update(@RequestBody ProductDTO Product, @PathVariable(name = "id") String id) {
		return service.update(id, Product);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "products/{id}")
	public ProductDTO delete(@PathVariable(name = "id") String id) {
		return service.delete(id);
	}

	@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Invalid model")
	@ExceptionHandler({ ModelNotFoundException.class })
	public void modelexception() {

	}
	/*
	 * @ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Invalid name")
	 * 
	 * @ExceptionHandler({NameNotFound.class}) public void nameexception() {
	 * 
	 * }
	 */
}
