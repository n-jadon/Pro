package com.capgemini.Product_Cart_Management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Product_Cart_Management.dto.ProductDTO;
import com.capgemini.Product_Cart_Management.repository.IProductRepo;

@Transactional
@Service("service")
public class ProductServiceImpl implements IProductService {
	@Autowired
	IProductRepo repo;

	@Override
	public ProductDTO create(ProductDTO Product) {
		// TODO Auto-generated method stub
		return repo.create(Product);
	}

	@Override
	public ProductDTO update(String id, ProductDTO Product) {
		// TODO Auto-generated method stub
		return repo.update(id, Product);
	}

	@Override
	public ProductDTO delete(String id) {
		// TODO Auto-generated method stub
		return repo.delete(id);
	}

	@Override
	public List<ProductDTO> view() {
		// TODO Auto-generated method stub
		return repo.view();
	}

	@Override
	public ProductDTO findById(String id) {
		// TODO Auto-generated method stub
		return repo.findById(id);
	}

}
