package com.capgemini.Product_Cart_Management.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Product_Cart_Management.dto.ProductDTO;

@Repository
@Transactional
public class ProductRepoImpl implements IProductRepo {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public ProductDTO create(ProductDTO Product) {
		// TODO Auto-generated method stub
		entityManager.persist(Product);

		return Product;
	}

	@Override
	public ProductDTO update(String id, ProductDTO Product) {
		// TODO Auto-generated method stub
		return entityManager.merge(Product);
	}

	@Override
	public ProductDTO delete(String id) {
		// TODO Auto-generated method stub
		ProductDTO s = (ProductDTO) entityManager.find(ProductDTO.class, id);
		entityManager.remove(s);
		return s;
	}

	@Override
	public List<ProductDTO> view() {
		// TODO Auto-generated method stub
		Query query = entityManager.createQuery("select products from ProductDTO products");
		// return null;
		return query.getResultList();

	}

	@Override
	public ProductDTO findById(String id) {
		return (ProductDTO) entityManager.find(ProductDTO.class, id);
	}

}
