package com.capgemini.ProductCartManagement.Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.ProductCartManagement.Repo.ProductRepoImpl;
import com.capgemini.ProductCartManagement.bean.Product;

@Service("service")
@Transactional
public class ProductServiceImpl implements IProductService{

	@Autowired
	ProductRepoImpl productRef;
	
	@Override
	public Product create(Product product) {
		// TODO Auto-generated method stub
		return productRef.create(product);
	}

	@Override
	public List<Product> view() {
		// TODO Auto-generated method stub
		return productRef.view();
	}

	@Override
	public Product find(String id) {
		// TODO Auto-generated method stub
		return productRef.find(id);
	}

	@Override
	public Product update(Product product) {
		// TODO Auto-generated method stub
		return productRef.update(product);
	}

	@Override
	public Product delete(String id) {
		// TODO Auto-generated method stub
		return productRef.delete(id);
	}

}
