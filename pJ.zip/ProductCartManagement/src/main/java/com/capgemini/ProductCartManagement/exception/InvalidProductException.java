package com.capgemini.ProductCartManagement.exception;

public class InvalidProductException extends RuntimeException{

}
