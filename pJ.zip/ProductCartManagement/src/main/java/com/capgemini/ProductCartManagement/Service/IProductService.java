package com.capgemini.ProductCartManagement.Service;

import java.util.List;

import com.capgemini.ProductCartManagement.bean.Product;

public interface IProductService {
	public Product create(Product product);
	public List<Product> view();
	public Product find(String id);
	public Product update(Product product);
	public Product delete(String id);
}
