package com.capgemini.ProductCartManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.ProductCartManagement.exception.InvalidProductException;
import com.capgemini.ProductCartManagement.Service.ProductServiceImpl;
import com.capgemini.ProductCartManagement.bean.Product;

@RestController
@RequestMapping("products")
public class ProductController {
	@Autowired
	ProductServiceImpl service;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Product> view(){
		return service.view();
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public Product create(@RequestBody Product product)
	{
		return service.create(product);
	}
	
	@RequestMapping(method=RequestMethod.GET,value="{id}")
	public Product find(@PathVariable(value="id") String id) {
		Product product=service.find(id);
		if(product==null)
			throw new InvalidProductException();
		return product;
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="{id}")
	public Product update(@RequestBody Product product,@PathVariable(value="id") String id) {
		Product IdProduct=service.find(id);
		if(IdProduct==null)
			throw new InvalidProductException();
		return service.update(product);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="{id}")
	public Product delete(@PathVariable(value="id") String id) {
		Product product=service.find(id);
		if(product==null)
			throw new InvalidProductException();
		return service.delete(id);
	}
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Id Does not exist")
	@ExceptionHandler({InvalidProductException.class})
	public void handleException()
	{	
	}
}
